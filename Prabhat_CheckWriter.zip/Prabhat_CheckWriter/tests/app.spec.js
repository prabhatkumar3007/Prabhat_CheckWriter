describe('Test Controller', function() {
    beforeEach(angular.mock.module('myApp'));
	var $controller, $scope, controller;

  beforeEach(inject(function(_$controller_){
    $controller = _$controller_;
  }));
    
    beforeEach(function() {
      $scope = {};
      controller = $controller('myCtrl', { $scope: $scope });
    });

    it('should return Sixty Nine dollars  only if the input number is 69', function() {
      $scope.inputNumber = '69';
      $scope.output = $scope.converter();
      expect($scope.output).toEqual(' Sixty Nine dollars  only');
    });
	
	it('should return One Hundred and Twenty Five dollars  and 75/100 if the input number is 125.75', function() {
      $scope.inputNumber = '125.75';
      $scope.output = $scope.converter();
      expect($scope.output).toEqual(' One Hundred and Twenty Five dollars  and 75/100');
    });
	
	it('should return Ninety Five dollars  only if the input number is 95.00', function() {
      $scope.inputNumber = '95.00';
      $scope.output = $scope.converter();
      expect($scope.output).toEqual(' Ninety Five dollars  only');
    });
	
	it('should return "Invalid Input" if the input number is in negative', function() {
      $scope.inputNumber = '-4';
      $scope.output = $scope.converter();
      expect($scope.output).toEqual("Invalid Input");
    });
	
});